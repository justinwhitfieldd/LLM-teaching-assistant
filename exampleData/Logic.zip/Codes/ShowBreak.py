#ShowBreak.py
""" Illustrates the use of the break command.
    Encourages the user to input a nonnegative integer because
    that is what the factorial function requires.
"""
import math
while True:
   N = raw_input('Enter a nonnegative integer: ')
   # Convert the input string to an int.
   N = int(N)
   if N>=0:
      # Valid input. Terminate the loop.
      break
   else:
      # Invalid input. Inform the user and the iteration continues.
      print 'N must be nonnegative.'
      
M = math.factorial(N)
print '\n\n%1d! = %1d' % (N,M)