#ShowTryBreak.py

""" Illustrates the use of try-except.
    Encourages the user to input a positive integer because
    that is what the factorial function requires.
"""
import math

while True:
    N = raw_input('Enter a nonegative integer:  ')
    try:
        # Convert the input string to an int.
        N = int(N)
        # Valid input. Terminate the loop.
        if N>=0:
           break
        else:
            print 'N must be nonnegative.'
    except ValueError:
        # Invalid input. Inform the user and the iteration continues.
        print 'N must have type  int'

M = math.factorial(N)
print '\n\n%1d! = %1d' % (N,M)

