# ShowAssert.py
""" Shows how assert can be used to check multiple preconsitions."""
   
import string
def TimeToMinutes(T):
    """ Returns the total number of minutes that have elapsed from midnight to
    the time specified by T.
    
    PreC: T is a time string of the form hh:mm where hh specifies the hour (between 0 and 23)
    and mm specifies minutes (between 0 and 59).
    
    Valid time strings: '00:00', '12:34', 23:59'
    Invalid time strings: '1:23', '24:01', '01:78', 'xy:zw'"""
    
    # Check that the preconditions are satisfied, i.e., that  T is a valid time string.
    assert isinstance(T,str), 'T mustbe a string.'
    assert len(T)==5,'Time strings must have length 5.'
    assert T[2]==':','The third character must be a colon.'
    assert T[0] in string.digits and T[1] in string.digits,'s[0:2] must specify an integer'
    assert 0<=int(T[0:2]) <=23, 'Must have 0<=int(T[0:2])<=23'
    assert T[3] in string.digits and T[3] in string.digits,'T[3:5] must specify an integer'
    assert 0<=int(T[3:5]) <=59, 'Must have 0<=int(T[3:5])<=59'
    M=60*int(T[0:2]) + int(T[3:5])
    # Check that the proper type is returned
    assert isinstance(M,int), 'An int value must be returned.'
    return M

def MinutesToTime(M):
    """ Returns a time string of the form hh:mm that is M minutes
    past midnight.
    
    PreC: M is an int that satisfies 0<=M<24*60. """
    
    # Check that the preconditions are satisfied.
    assert isinstance(M,int), 'M must have type int'
    assert M<24*60, 'M must satisfy 0<=m<24*60'
    # Compute the hours and minutes associated with M...
    hours = M/60
    minutes = M%60
    # Compute the time string and check that the post condition is satisfied...
    T = str(hours) + ':' + str(minutes)
    assert isinstance(T,str), 'T mustbe a string.'
    assert len(T)==5,'Time strings must have length 5.'
    assert T[2]==':','The third character must be a colon.'
    assert T[0] in string.digits and T[1] in string.digits,'s[0:2] must specify an integer'
    assert 0<=int(T[0:2]) <=23, 'Must have 0<=int(T[0:2])<=23'
    assert T[3] in string.digits and T[3] in string.digits,'T[3:5] must specify an integer'
    assert 0<=int(T[3:5]) <=59, 'Must have 0<=int(T[3:5])<=59'
    return T
    
# Application script...
if __name__== '__main__':
    """ Solicits a time string, converts it to minutes, and then converts the
    computed number of minutes back to the equivalent time string."""
    
    T = raw_input('Enter a time string of the form hh:mm : ')
    print T
    M = TimeToMinutes(T)
    print M
    T = MinutesToTime(M)
    print T
